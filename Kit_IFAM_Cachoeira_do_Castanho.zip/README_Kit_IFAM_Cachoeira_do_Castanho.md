# Kit IFAM Campus Iranduba — Levantamento de Requisitos

Este pacote reúne documentos profissionais para orientar estudantes em uma visita técnica à **Comunidade Cachoeira do Castanho**, com foco no levantamento de requisitos para desenvolvimento de um site comunitário.

A identidade visual utiliza as cores institucionais dos Institutos Federais indicadas no manual de aplicação da marca: verde `#2f9e41`, vermelho `#cd191e`, preto `#000000` e fundos claros de apoio. O material também adota estrutura textual compatível com atividade acadêmica e linguagem adequada para alunos.

## Arquivos incluídos

| Arquivo | Finalidade |
|---|---|
| `01_Guia_de_Campo_IFAM_Cachoeira_do_Castanho.docx` e `.pdf` | Orienta preparação, conduta, materiais, informações a coletar, roteiro da visita e entregas esperadas. |
| `02_Questionario_de_Entrevista_IFAM_Cachoeira_do_Castanho.docx` e `.pdf` | Reúne perguntas sem respostas e termo simples de autorização para uso acadêmico de imagem, áudio e informações. |
| `03_Modelo_Relatorio_Matriz_Requisitos_IFAM_Cachoeira_do_Castanho.docx` e `.pdf` | Traz modelo de relatório, matriz de requisitos, checklist de anexos e critérios sugeridos de avaliação. |
| `cabecalho_ifam_iranduba.png` | Arte de cabeçalho institucional usada nos documentos. |

## Referências

[1] Manual de Aplicação da Marca Instituto Federal, Ministério da Educação. Disponível em: <https://www.gov.br/mec/pt-br/assuntos/ept/rede-federal/institutos-federais-de-educacao-ciencia-e-tecnologia/manualidentidadevisualif2024.pdf>

[2] Site oficial do IFAM Campus Iranduba. Disponível em: <https://cir.ifam.edu.br/>
